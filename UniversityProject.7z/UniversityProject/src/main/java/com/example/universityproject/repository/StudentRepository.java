package com.example.universityproject.repository;

import com.example.universityproject.model.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends CrudRepository<Student, Integer> {
}