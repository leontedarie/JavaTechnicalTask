package com.example.universityproject;

import com.example.universityproject.model.Faculty;
import com.example.universityproject.model.Student;
import com.example.universityproject.model.University;
import com.example.universityproject.repository.FacultyRepository;
import com.example.universityproject.repository.StudentRepository;
import com.example.universityproject.repository.UniversityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class CommandsService {

    @Autowired
    private UniversityRepository universityRepository;

    @Autowired
    private FacultyRepository facultyRepository;

    @Autowired
    private StudentRepository studentRepository;

    public CommandsService() {
    }


    public void deleteUniversity() {
    }

    public void createUniversity(String name,String address) {
        University university = new University();
        university.setName(name);
        university.setAddress(address);
        universityRepository.save(university);
    }
    public void addFaculty(String universityName, String facultyName, String specialtyName) {
        //University univ = universityRepository.findByName(universityName);
        //if(univ!=null){
            Faculty faculty = new Faculty();
            faculty.setName(facultyName);
            faculty.setSpecialtyName(specialtyName);
            //faculty.setUniversity(univ);
            //univ.getFaculties().add(faculty);
            facultyRepository.save(faculty);
       // }
    }

    public void removeFaculty(Integer id) {
        facultyRepository.deleteById(id);
    }

    public void displayAllUniversities() {
        for (University univ : universityRepository.findAll()) {
            System.out.println(univ.getId() + ": " + "Name: " + univ.getName() + "," + "Address: " + univ.getAddress() + "Faculty: " + univ.getFacultyName());
        }
    }

    public void displayAllFaculties() {
        for (Faculty faculty : facultyRepository.findAll()) {
            System.out.println(faculty.getId() + ": " + "Name: " + faculty.getName() + "," + "Specialty: " + faculty.getSpecialtyName());
        }
    }


    public void createStudent(String studentName, String groupName, int phone) {
        Student student = new Student();
        student.setName(studentName);
        student.setGroupName(groupName);
        student.setPhoneNumber(phone);
        studentRepository.save(student);
    }

    public void displayAllStudents() {
        for (Student s : studentRepository.findAll()) {
            System.out.println(s.getId() + ": " + s.getName() + ", Group: " + s.getGroupName() + ", Phone: " + s.getPhoneNumber());
        }
    }
}
