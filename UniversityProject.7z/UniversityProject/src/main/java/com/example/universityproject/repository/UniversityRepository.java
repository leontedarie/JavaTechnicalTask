package com.example.universityproject.repository;

import com.example.universityproject.model.University;
import org.springframework.data.repository.CrudRepository;

public interface UniversityRepository extends CrudRepository<University, Integer> {
    University findByName(String name);
}