package com.example.universityproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class Application implements CommandLineRunner {

    @Autowired
    private CommandsService commandsService;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println("1. press 1 to create university");
        System.out.println("2. press 2 to add faculty");
        System.out.println("3. press 3 to remove faculty");
        System.out.println("4. press 4 to display all universities");
        System.out.println("5. press 5 to create a new student");
        System.out.println("6. press 5 to display all students");
        System.out.println("Try a command or type exit for exit:");

        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextInt()) {
            int command = scanner.nextInt();
            switch (command) {
                case 1:
                    System.out.println("Please enter the university name below:");
                    String universityName = scanner.next();
                    System.out.println("Please enter the address below:");
                    String address = scanner.next();
                    commandsService.createUniversity(universityName,address);
                    System.out.println("New university was created :" + universityName);
                    break;
                case 2:
                    System.out.println("Please enter the university name where you want to add new faculty:");
                    universityName = scanner.next();
                    System.out.println("Please enter the faculty name:");
                    String facultyName = scanner.next();
                    System.out.println("Please enter the specialty name:");
                    String specialtyName = scanner.next();
                    commandsService.addFaculty(universityName, facultyName, specialtyName);
                    System.out.println("New faculty was created :" + facultyName);
                    break;
                case 3:
                    int id = scanner.nextInt();
                    commandsService.removeFaculty(id);
                    System.out.println("Command 3 executed");
                    break;
                case 4:
                    commandsService.displayAllUniversities();
                    System.out.println("Command 4 executed");
                    break;
                case 5:
                    System.out.println("Please enter the student name below:");
                    String studentName = scanner.next();
                    System.out.println("Please enter the group name:");
                    String groupName = scanner.next();
                    System.out.println("Please enter the phone number:");
                    int phoneNumber = scanner.nextInt();
                    commandsService.createStudent(studentName, groupName, phoneNumber);
                    System.out.println("Student Name introduced :" + studentName);
                    break;
                case 6:
                    commandsService.displayAllStudents();
                    System.out.println("Command 6 executed");
                    break;
                case 7:
                    commandsService.displayAllFaculties();
                    System.out.println("Command 4 executed");
                    break;
                default:
                    System.out.println("Command does not exist");
                    break;
            }
            System.out.println("Try another command or type exit for exit:");
        }
    }
}