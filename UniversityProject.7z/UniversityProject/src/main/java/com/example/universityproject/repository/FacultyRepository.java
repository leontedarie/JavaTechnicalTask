package com.example.universityproject.repository;

import com.example.universityproject.model.Faculty;
import org.springframework.data.repository.CrudRepository;

public interface FacultyRepository extends CrudRepository<Faculty, Integer> {
}